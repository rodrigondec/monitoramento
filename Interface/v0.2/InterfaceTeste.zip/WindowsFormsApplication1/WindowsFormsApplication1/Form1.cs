﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        string RxString;

        public Form1()
        {
            InitializeComponent();

            Graph.Legends.Clear();
            Graph1.Legends.Clear();
            Graph2.Legends.Clear();

            Graph.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Range;
            Graph1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Range;
            Graph2.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Range;

            Graph.ChartAreas[0].AxisY.Maximum = 100;
            Graph1.ChartAreas[0].AxisY.Maximum = 150;
            Graph2.ChartAreas[0].AxisY.Maximum = 100;

            Graph.ChartAreas[0].AxisX.Minimum = 1;
            Graph.ChartAreas[0].AxisX.Maximum = 9;

            Graph1.ChartAreas[0].AxisX.Minimum = 1;
            Graph1.ChartAreas[0].AxisX.Maximum = 9;

            Graph2.ChartAreas[0].AxisX.Minimum = 1;
            Graph2.ChartAreas[0].AxisX.Maximum = 9;
        
            this.Width = 160;
            this.Height = 185;
        }

        int valor1, valor2, valor3;

        private void Form1_Load(object sender, EventArgs e)
        {
            atualizaListaCOMs();
            comboBox2.SelectedIndex = 0;
            comboBox3.SelectedIndex = 0;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            atualizaListaCOMs();
        }

        private void atualizaListaCOMs()
        {
            int i;
            bool quantDiferente;    //flag para sinalizar que a quantidade de portas mudou

            i = 0;
            quantDiferente = false;

            //se a quantidade de portas mudou
            if (comboBox1.Items.Count == SerialPort.GetPortNames().Length)
            {
                foreach (string s in SerialPort.GetPortNames())
                {
                    if (comboBox1.Items[i++].Equals(s) == false)
                    {
                        quantDiferente = true;
                    }
                }
            }
            else
            {
                quantDiferente = true;
            }

            //Se não foi detectado diferença
            if (quantDiferente == false)
            {
                return;                     //retorna
            }

            //limpa comboBox
            comboBox1.Items.Clear();

            //adiciona todas as COM diponíveis na lista
            foreach (string s in SerialPort.GetPortNames())
            {
                comboBox1.Items.Add(s);
            }
            //seleciona a primeira posição da lista
            comboBox1.SelectedIndex = 0;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen == false)
            {
                try
                {
                    serialPort1.PortName = comboBox1.Items[comboBox1.SelectedIndex].ToString();
                    serialPort1.BaudRate = int.Parse(comboBox2.Items[comboBox2.SelectedIndex].ToString());
                    serialPort1.Open();
                }
                catch
                {
                    return;
                }

                if (serialPort1.IsOpen)
                {
                    button3.Text = "Desconectar";
                    comboBox1.Enabled = false;
                    comboBox2.Enabled = false;
                    comboBox3.Enabled = false;
                    this.Width = 775;
                    this.Height = 315;
                }
            }
            else
            {

                try
                {
                    serialPort1.Close();
                    comboBox1.Enabled = true;
                    comboBox2.Enabled = true;
                    comboBox3.Enabled = true;
                    button3.Text = "Conectar";
                }
                catch
                {
                    return;
                }

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen == true)          //porta está aberta
                serialPort1.Write("Teste");      
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (serialPort1.IsOpen == true)  // se porta aberta
                serialPort1.Close();         //fecha a porta
        }

        private void trataDadoRecebido(object sender, EventArgs e)
        {
            textBoxReceber.Text = "";
            
            string pattern = "(:)";

            string[] substrings = System.Text.RegularExpressions.Regex.Split(RxString, pattern);    // Split on hyphens
             
            //string valor = String.Join("", System.Text.RegularExpressions.Regex.Split(RxString, @"[^\d]"));

            if (!(Int32.TryParse(substrings[0], out valor1)))
            {
                valor1 = progressBar1.Value;
            }

            if (!(Int32.TryParse(substrings[2], out valor2)))
            {
                valor2 = progressBar3.Value;
            }

            if (!(Int32.TryParse(substrings[4], out valor3)))
            {
                valor3 = progressBar3.Value;
            }

            //textBoxReceber.Text = j.ToString() + "% da Capacidade";

            if (valor1 >= 0 && valor1 <= 100)
            {
                progressBar1.Value = valor1;
            }

            if (valor2 >= 0 && valor2 <= 100)
            {
                progressBar2.Value = valor2;
            }

            if (valor3 >= 0 && valor3 <= 100)
            {
                progressBar3.Value = valor3;
            }

            atualizaTextBox();

            if (Graph.Series[0].Points.Count >= 9)
            {
                Graph.Series[0].Points.RemoveAt(0);
                Graph.Update();
            }

            if (Graph1.Series[0].Points.Count >= 9)
            {
                Graph1.Series[0].Points.RemoveAt(0);
                Graph1.Update();
            }


            if (Graph2.Series[0].Points.Count >= 9)
            {
                Graph2.Series[0].Points.RemoveAt(0);
                Graph2.Update();
            }

            Graph.Series[0].Points.AddXY(DateTime.Now.ToLongTimeString(), valor1);

            Graph1.Series[0].Points.AddXY(DateTime.Now.ToLongTimeString(), valor2);

            Graph2.Series[0].Points.AddXY(DateTime.Now.ToLongTimeString(), valor3);
        }

        private void serialPort1_DataReceived_1(object sender, SerialDataReceivedEventArgs e)
        {
            RxString = serialPort1.ReadLine();                      //le o dado disponível na serial
            this.Invoke(new EventHandler(trataDadoRecebido));       //chama outra thread para escrever o dado no text box
        }

        private void atualizaTextBox()
        {
            switch (tabControl1.SelectedIndex)
            {
                case 0:
                    textBoxReceber.Text = valor1.ToString() + "% de Luminosidade \n";
                    break;

                case 1:
                    textBoxReceber.Text = valor2.ToString() + "° Celsius";
                    break;

                case 2:
                    textBoxReceber.Text = valor3.ToString() + "db";
                    break;
            }
        }

        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            atualizaTextBox();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox3.SelectedIndex != 0)
            {
                comboBox1.Enabled = false;
                comboBox2.Enabled = false;
                button5.Enabled = false;
                button3.Enabled = false;
                textBoxReceber.Enabled = false;
            }
            else
            {
                comboBox1.Enabled = true;
                comboBox2.Enabled = true;
                button5.Enabled = true;
                button3.Enabled = true;
                textBoxReceber.Enabled = true;
            }
        }
    }
}
